//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

class BinarySearchTreeBuilder {
    BSTNode root = null;

    BinarySearchTreeBuilder() {
    }

    protected BSTNode createNewNode(String var1, Record var2) {
        return new BSTNode(var1, var2);
    }

    public boolean contains(String var1, Record var2) {
        BSTNode var3 = this.root;

        while(var3 != null) {
            if (var1.compareTo(var3.keyword) < 0) {
                var3 = var3.left;
            } else {
                if (var1.compareTo(var3.keyword) <= 0) {
                    var2.next = var3.record;
                    var3.record = var2;
                    return true;
                }

                var3 = var3.right;
            }
        }

        return false;
    }

    void insert(String var1, FileData var2) {
        Record var3 = new Record(var2.id, var2.title, var2.author, (Record)null);
        if (!this.contains(var1, var3)) {
            this.insert(var1, var3);
        }

    }

    boolean insert(String var1, Record var2) {
        if (this.root == null) {
            this.root = this.createNewNode(var1, var2);
        } else {
            BSTNode var3 = null;
            BSTNode var4 = this.root;

            while(var4 != null) {
                if (var1.compareTo(var4.keyword) < 0) {
                    var3 = var4;
                    var4 = var4.left;
                    if (var4 == null) {
                        var3.left = this.createNewNode(var1, var2);
                    }
                } else if (var1.compareTo(var4.keyword) > 0) {
                    var3 = var4;
                    var4 = var4.right;
                    if (var4 == null) {
                        var3.right = this.createNewNode(var1, var2);
                    }
                }
            }
        }

        return true;
    }

    public boolean delete(String var1) {
        BSTNode var2 = null;
        BSTNode var3 = this.root;

        while(var3 != null) {
            if (var1.compareTo(var3.keyword) < 0) {
                var2 = var3;
                var3 = var3.left;
            } else {
                if (var1.compareTo(var3.keyword) <= 0) {
                    break;
                }

                var2 = var3;
                var3 = var3.right;
            }
        }

        if (var3 == null) {
            return false;
        } else {
            if (var3.left == null) {
                if (var2 == null) {
                    this.root = var3.right;
                } else if (var1.compareTo(var2.keyword) < 0) {
                    var2.left = var3.right;
                } else {
                    var2.right = var3.right;
                }
            } else {
                BSTNode var4 = var3;

                BSTNode var5;
                for(var5 = var3.left; var5.right != null; var5 = var5.right) {
                    var4 = var5;
                }

                var3.keyword = var5.keyword;
                if (var4.right == var5) {
                    var4.right = var5.left;
                } else {
                    var4.left = var5.left;
                }
            }

            return true;
        }
    }

    public void print() {
        System.out.println("****************** print(Sorted)***************");
        this.printInOrder(this.root);
    }

    private void printInOrder(BSTNode var1) {
        if (var1 != null) {
            this.printInOrder(var1.left);
            System.out.println(var1.keyword);
            Record var2 = var1.record;
            System.out.print("\t");

            while(var2 != null) {
                System.out.printf("%d|%s|%s ---> ", var2.id, var2.author, var2.title);
                var2 = var2.next;
            }

            System.out.println("null");
            this.printInOrder(var1.right);
        }

    }
}
