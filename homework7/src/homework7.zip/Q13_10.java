public class Q13_10 {

    public static void main(String[] args) {
        // write your code here
        Rectangle r1 = new Rectangle(30, 30);
        Rectangle r2 = new Rectangle(40, 50);
        Rectangle r3 = new Rectangle(50, 50);
        Rectangle r4 = new Rectangle(50, 50);

        //prompts
        System.out.println("Comparison of Rectangle 1 and Rectangle 2: "+ r1.equals(r2));
        System.out.println("Comparison of Rectangle 3 and Rectangle 4: "+ r3.equals(r4));
    }
}


