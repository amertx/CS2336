public class Q13_9 {

    public static void main(String[] args) {
        // write your code here
        Circle circle1 = new Circle(20);
        Circle circle2 = new Circle(30);
        Circle circle3 = new Circle(40);
        Circle circle4 = new Circle(40);

        System.out.println("Comparison of circle1 and circle 2: "+ circle1.equals(circle2));
        System.out.println("Comparison of circle3 and circle 4: "+ circle3.equals(circle4));

    }
}





